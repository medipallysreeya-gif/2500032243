import java.util.*;

public class MentalGardenDSA {

    static Scanner sc = new Scanner(System.in);

    static LinkedList<String> seeds = new LinkedList<>();
    static Stack<String> growthStack = new Stack<>();
    static Queue<String> careQueue = new LinkedList<>();
    static ArrayList<Integer> surveyData = new ArrayList<>();
    static HashMap<Integer,String> recovery = new HashMap<>();
    static PriorityQueue<String> medicines = new PriorityQueue<>();

    public static void main(String[] args) {

        int choice;

        do{

            System.out.println("\n---- MENTAL GARDEN ----");
            System.out.println("1 Home");
            System.out.println("2 Seeds");
            System.out.println("3 Growth");
            System.out.println("4 Care");
            System.out.println("5 Weeds");
            System.out.println("6 Survey");
            System.out.println("7 Case Studies");
            System.out.println("8 Medicines");
            System.out.println("9 Guide");
            System.out.println("10 Recovery");
            System.out.println("0 Exit");

            choice = sc.nextInt();
            sc.nextLine();

            switch(choice){

                case 1: home(); break;
                case 2: seeds(); break;
                case 3: growth(); break;
                case 4: care(); break;
                case 5: weeds(); break;
                case 6: survey(); break;
                case 7: caseStudies(); break;
                case 8: medicines(); break;
                case 9: guide(); break;
                case 10: recovery(); break;

            }

        }while(choice!=0);

    }

    // HOME
    static void home(){

        System.out.println("Welcome to Mental Garden");
        System.out.println("Grow your mind like a garden.");
    }

    // SEEDS (LinkedList)
    static void seeds(){

        System.out.println("Enter a goal to plant:");
        String goal = sc.nextLine();

        seeds.add(goal);

        System.out.println("Seeds planted:");
        for(String s:seeds)
            System.out.println(s);
    }

    // GROWTH (Stack)
    static void growth(){

        System.out.println("Enter activity completed:");
        String act = sc.nextLine();

        growthStack.push(act);

        System.out.println("Recent growth activity:");
        System.out.println(growthStack.peek());
    }

    // CARE (Queue)
    static void care(){

        System.out.println("Enter self-care task:");
        String task = sc.nextLine();

        careQueue.add(task);

        System.out.println("Next task to complete:");
        System.out.println(careQueue.peek());
    }

    // WEEDS (Array)
    static void weeds(){

        String weeds[] = {"Overthinking","Procrastination","Negative thoughts"};

        System.out.println("Bad habits:");

        for(int i=0;i<weeds.length;i++)
            System.out.println(i+" "+weeds[i]);

        System.out.println("Choose weed to remove:");

        int w = sc.nextInt();

        System.out.println(weeds[w]+" removed from garden.");
    }

    // SURVEY (ArrayList + Graph)
    static void survey(){

        System.out.println("Enter stress levels for 5 days (1-5)");

        surveyData.clear();

        for(int i=0;i<5;i++){
            int level = sc.nextInt();
            surveyData.add(level);
        }

        System.out.println("Mood Graph:");

        for(int i=0;i<surveyData.size();i++){

            System.out.print("Day "+(i+1)+": ");

            for(int j=0;j<surveyData.get(i);j++)
                System.out.print("*");

            System.out.println();
        }
    }

    // CASE STUDIES (Sorting)
    static void caseStudies(){

        String stories[] = {"Anna recovery","John success","Maya progress","David growth"};

        Arrays.sort(stories);

        System.out.println("Sorted Case Studies:");

        for(String s:stories)
            System.out.println(s);
    }

    // MEDICINES (PriorityQueue)
    static void medicines(){

        medicines.add("Meditation");
        medicines.add("Exercise");
        medicines.add("Healthy sleep");
        medicines.add("Journaling");

        System.out.println("Recommended help methods:");

        while(!medicines.isEmpty())
            System.out.println(medicines.poll());
    }

    // GUIDE (Form)
    static void guide(){

        System.out.println("---- GUIDE FORM ----");

        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("Age: ");
        int age = sc.nextInt();
        sc.nextLine();

        System.out.print("Gender: ");
        String gender = sc.nextLine();

        System.out.print("Problem: ");
        String problem = sc.nextLine();

        System.out.print("Duration of issue: ");
        String duration = sc.nextLine();

        System.out.println("Suggestions:");

        if(problem.equalsIgnoreCase("Stress"))
            System.out.println("Try meditation and breathing.");
        else
            System.out.println("Maintain healthy routines.");
    }

    // RECOVERY (HashMap)
    static void recovery(){

        recovery.put(1,"Day1 Improved mood");
        recovery.put(2,"Day2 Less stress");
        recovery.put(3,"Day3 Better sleep");

        System.out.println("Recovery history:");

        for(Map.Entry<Integer,String> e: recovery.entrySet())
            System.out.println(e.getKey()+" "+e.getValue());
    }

}